<?php
    define('BROWSER_TITLE', '我的网站 - by Flen Plnens'); // 在浏览器标签页中显示的标题
    define('PAGE_TITLE', '我的网站'); // 在页面中显示的标题
    define('PAGE_DESCRIPTION', '这里是网站的介绍。');// 在页面中显示的简介
    define('USE_HTTPS', true); // 更改为true或false来表示使用HTTP或HTTPS
?>
